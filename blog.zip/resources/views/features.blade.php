@extends('layout/layout')

@section('title' , 'index')

@section('container')
<section>
    <div class="container-fluid">
  
    </div>
</section>

@endsection