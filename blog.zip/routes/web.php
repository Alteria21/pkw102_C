<?php
use Illuminate\Support\Facades\Route;
// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/features', function () {
//     return view('features');
// });

// Route::get('/pricing', function () {
//     return view('pricing');
// });

Route::get('/' , 'PagesController@home');
Route::get('/features', 'PagesController@features');
Route::get('/pricing', 'PagesController@pricing');
Route::get('/mahasiswa/index','MahasiswaController@index');

Route::get('halo', function(){
return 'ini mencoba ';
});

Route::get('dosen','DosenController@index');

Route::get('/students', 'StudentsController@index');

Route::get('/students/{student}', 'StudentsController@show');

Route::get('/students/create', 'StudentsController@create');

Route::post('/students', 'StudentsController@store');
