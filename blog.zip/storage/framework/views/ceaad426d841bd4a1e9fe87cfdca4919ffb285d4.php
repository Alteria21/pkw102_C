<?php $__env->startSection('title' , 'index'); ?>

<?php $__env->startSection('container'); ?>
<section>
    <div class="container-fluid">
        <!-- jummbotron -->
        <div class="jumbotron">
            <div class="container">
                <h1 class="display-4">Welcome</h1>
                <p class="lead">First time make a framework LARAVEL project</p>
            </div>
        </div>
        <!-- akhir jumbotron -->
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views//welcome.blade.php ENDPATH**/ ?>