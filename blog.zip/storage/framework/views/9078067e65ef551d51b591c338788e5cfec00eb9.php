<?php $__env->startSection('title' , 'index'); ?>

<?php $__env->startSection('container'); ?>
<section>
    <div class="container-fluid">
        <table class="table" style="border: solid">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama</th>
                    <th scope="col">NRP</th>
                    <th scope="col">Email</th>
                    <th scope="col">Jurusan</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>angga wika nugraha</td>
                    <td>20170140106</td>
                    <td>anggawika18@gmail.com</td>
                    <td>Teknik informatika</td>
                    <td>
                        <a href="" class="badge badge-succes">edit</a>
                        <a href="" class="badge badge-danger">edit</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views//mahasiswa/index.blade.php ENDPATH**/ ?>