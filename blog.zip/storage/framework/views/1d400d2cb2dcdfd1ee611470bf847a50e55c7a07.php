<?php $__env->startSection('title' , 'index'); ?>

<?php $__env->startSection('container'); ?>
<section>
    <div class="container-fluid">
  
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views//features.blade.php ENDPATH**/ ?>